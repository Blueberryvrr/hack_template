import customtkinter as ctk
import pymem
import pymem.process
import traceback
import sys
from tkinter import messagebox

APP_SIZE = "400x260"
FONT = ("Segoe UI Variable", 13)
PROCESS_NAME = "template.exe"
HEALTH_OFFSET = 0x0010F4F4
GEMS_OFFSET = 0x0010F500

def attach_process(process_name: str):
    try:
        pm = pymem.Pymem(process_name)
        return pm
    except Exception as e:
        raise RuntimeError(f"Failed to attach to process '{process_name}': {e}")

def get_module_base(pm: pymem.Pymem, module_name: str):
    try:
        module = pymem.process.module_from_name(pm.process_handle, module_name)
        if not module or not hasattr(module, "lpBaseOfDll"):
            raise RuntimeError("module_from_name returned invalid module object")
        return module.lpBaseOfDll
    except Exception as e:
        raise RuntimeError(f"Could not find module '{module_name}': {e}")

def safe_write_bytes(pm: pymem.Pymem, address: int, data: bytes):
    try:
        pm.write_bytes(address, data, len(data))
    except Exception as e:
        raise RuntimeError(f"Failed to write bytes at 0x{address:08X}: {e}")

def safe_write_int(pm: pymem.Pymem, address: int, value: int):
    try:
        pm.write_int(address, value)
    except Exception as e:
        raise RuntimeError(f"Failed to write int at 0x{address:08X}: {e}")

def setup_connection():
    try:
        pm = attach_process(PROCESS_NAME)
        module_base = get_module_base(pm, PROCESS_NAME)
        return pm, module_base
    except Exception as e:
        tb = traceback.format_exc()
        print("=== Attach Error ===")
        print(tb)
        messagebox.showerror("Process Error", str(e))
        raise

def set_template_health(pm: pymem.Pymem, module_base: int, enable: bool):
    address = module_base + HEALTH_OFFSET
    if enable:
        try:
            safe_write_bytes(pm, address, b"\x90" * 8)
            return "inf health enabled", "lightgreen"
        except Exception as e:
            return f"error: {e}", "red"
    else:
        try:
            original_bytes = b"\x89\x86\x88\x00\x00\x00\x8B\xCE"
            safe_write_bytes(pm, address, original_bytes)
            return "inf health disabled", "red"
        except Exception as e:
            return f"error: {e}", "red"

def set_template_gems(pm: pymem.Pymem, module_base: int, new_gems: int):
    address = module_base + GEMS_OFFSET
    try:
        safe_write_int(pm, address, new_gems)
        return f"set gems to {new_gems}", "lightgreen"
    except Exception as e:
        return f"error: {e}", "red"

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("green")

app = ctk.CTk()
app.title("template mod")
app.geometry(APP_SIZE)

frame = ctk.CTkFrame(app)
frame.pack(pady=20, padx=20, fill="both", expand=True)

status = ctk.StringVar(value="Ready")
pm = None
module_base = None
try:
    pm, module_base = setup_connection()
    status.set(f"Attached to {PROCESS_NAME} (base 0x{module_base:08X})")
except Exception:
    status.set("Not attached — see error dialog")

health_toggle = ctk.BooleanVar(value=False)

def toggle_dhealth():
    global pm, module_base
    if pm is None or module_base is None:
        try:
            pm, module_base = setup_connection()
            status.set(f"Attached to {PROCESS_NAME} (base 0x{module_base:08X})")
        except Exception:
            status.set("Not attached — see error dialog")
            return

    msg, color = set_template_health(pm, module_base, health_toggle.get())
    status.set(msg)
    status_label.configure(text_color=color)

checkbox = ctk.CTkCheckBox(frame, text="inf health", font=FONT, variable=health_toggle, command=toggle_dhealth)
checkbox.pack(anchor="w", pady=6)

ctk.CTkLabel(frame, text="gems", font=FONT).pack(anchor="w", pady=(8, 0))
input_frame = ctk.CTkFrame(frame, fg_color="transparent")
input_frame.pack(fill="x", pady=6)

entry = ctk.CTkEntry(input_frame, placeholder_text="new gems", font=FONT)
entry.pack(side="left", fill="x", expand=True, padx=(0, 8))

def confirm_gems():
    global pm, module_base
    if pm is None or module_base is None:
        try:
            pm, module_base = setup_connection()
            status.set(f"Attached to {PROCESS_NAME} (base 0x{module_base:08X})")
        except Exception:
            status.set("Not attached — see error dialog")
            return

    try:
        value = int(entry.get() or 0)
        msg, color = set_template_gems(pm, module_base, value)
        status.set(msg)
        status_label.configure(text_color=color)
    except ValueError:
        status.set("invalid gems")
        status_label.configure(text_color="red")

ctk.CTkButton(input_frame, text="Confirm", font=FONT, command=confirm_gems).pack(side="right")

status_label = ctk.CTkLabel(frame, textvariable=status, font=FONT, text_color="lightgreen")
status_label.pack(anchor="w", pady=(12, 0))

hint_text = (
    "If attach fails, try:\n"
    "- Run this script as Administrator\n"
    "- Get better lol\n"
    "- Confirm process name exactly (template.exe)\n"
    "- Ensure the target process is 32/64-bit matching your Python/pymem\n"
    "- Disable anti-cheat/AV interfering with memory writes"
)
ctk.CTkLabel(frame, text=hint_text, font=("Segoe UI Variable", 9), wraplength=360, text_color="#AAAAAA").pack(anchor="w", pady=(8, 0))

app.mainloop()
